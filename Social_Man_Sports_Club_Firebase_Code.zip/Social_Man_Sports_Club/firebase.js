import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";
import { getFirestore, doc, getDoc, collection, setDoc, getDocs, query, orderBy, serverTimestamp, updateDoc } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
const firebaseConfig = {
 apiKey:"AIzaSyB85qTuffMNDPqCbz73l1kSLTPk4bKSZTE",
 authDomain:"social-man-sports-club.firebaseapp.com",
 projectId:"social-man-sports-club",
 storageBucket:"social-man-sports-club.firebasestorage.app",
 messagingSenderId:"542907704253",
 appId:"1:542907704253:web:ab54cc01dd010dbf8968d4",
 measurementId:"G-CQGBH12DL7"
};
// প্রথম Admin-এর UID পাওয়ার পর এখানে বসাবে
export const ADMIN_UID="PASTE_ADMIN_UID_HERE";
const app=initializeApp(firebaseConfig);
export const auth=getAuth(app), db=getFirestore(app);
export {RecaptchaVerifier,signInWithPhoneNumber,onAuthStateChanged,signOut,doc,getDoc,collection,setDoc,getDocs,query,orderBy,serverTimestamp,updateDoc};
